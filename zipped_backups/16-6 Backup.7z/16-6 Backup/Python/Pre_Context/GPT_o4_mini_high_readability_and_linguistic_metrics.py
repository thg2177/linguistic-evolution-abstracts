"""
Script to compute readability and linguistic metrics for abstracts in an input CSV.
Metrics: word count, sentence count, avg sentence length, Flesch Reading Ease,
Flesch-Kincaid Grade Level, syllable count, Gunning Fog Index, complex word count,
SMOG Index, hedging frequency, hedging percentage, passive voice ratio,
nominalisation rate, lexical density.
"""

# Installation (run once):
# pip install pandas nltk textstat spacy
# python -m spacy download en_core_web_sm

import pandas as pd
import nltk
import textstat
import spacy
from nltk import word_tokenize, sent_tokenize

# Download NLTK resources (run once)
nltk.download('punkt')
nltk.download('averaged_perceptron_tagger')
nltk.download('stopwords')

# Load spaCy English model (run once)
nlp = spacy.load("en_core_web_sm")

# List of hedging words (expand as needed)
hedge_list = set([
    "may", "might", "could", "seems", "appears", "suggest", "likely", "possible",
    "possibly", "probable", "probably", "assume", "assumed", "indicative", "tends",
    "tend", "often", "sometimes", "somewhat"
])

def compute_metrics(text: str) -> dict:
    """
    Compute all required metrics for a single text string.
    Returns a dict with metric names as keys.
    """
    # Sentence and word tokenization
    sentences = sent_tokenize(text)
    sent_count = len(sentences)
    tokens = word_tokenize(text)
    # Filter to alphabetic tokens for word-based counts
    words = [w for w in tokens if w.isalpha()]
    word_count = len(words)
    avg_sentence_len = word_count / sent_count if sent_count > 0 else 0

    # Readability metrics via textstat
    flesch_reading = textstat.flesch_reading_ease(text)
    flesch_kincaid = textstat.flesch_kincaid_grade(text)
    syllable_count = textstat.syllable_count(text)
    gunning_fog = textstat.gunning_fog(text)
    complex_word_count = textstat.difficult_words(text)
    smog_index = textstat.smog_index(text)

    # Hedging metrics
    hedge_count = sum(1 for w in words if w.lower() in hedge_list)
    hedge_pct = (hedge_count / word_count * 100) if word_count > 0 else 0

    # Passive voice detection
    passive_sent_count = 0
    for sent in sentences:
        doc = nlp(sent)
        # "nsubjpass" dependency indicates a passive nominal subject
        if any(tok.dep_ == "nsubjpass" for tok in doc):
            passive_sent_count += 1
    passive_ratio = (passive_sent_count / sent_count) if sent_count > 0 else 0

    # Nominalisation rate: count tokens ending with nominalisation suffixes
    nominal_suffixes = ("ion", "ment", "ity", "ness", "ance", "ence", "ship")
    nominal_count = sum(1 for w in words if w.lower().endswith(nominal_suffixes))
    nominal_rate = (nominal_count / word_count * 100) if word_count > 0 else 0

    # Lexical density: ratio of lexical content words (nouns, verbs, adjectives, adverbs)
    doc_all = nlp(text)
    lexical_count = sum(1 for tok in doc_all if tok.pos_ in {"NOUN","VERB","ADJ","ADV"})
    lexical_density = (lexical_count / word_count * 100) if word_count > 0 else 0

    return {
        "Word Count": word_count,
        "Sentence Count": sent_count,
        "Average Sentence Length": round(avg_sentence_len, 2),
        "Flesch Reading Ease": round(flesch_reading, 2),
        "Flesch-Kincaid Grade Level": round(flesch_kincaid, 2),
        "Syllable Count": syllable_count,
        "Gunning Fog Index": round(gunning_fog, 2),
        "Complex Word Count": complex_word_count,
        "SMOG Index": round(smog_index, 2),
        "Hedging Frequency": hedge_count,
        "Hedging %": round(hedge_pct, 2),
        "Passive Voice Ratio": round(passive_ratio, 2),
        "Nominalisation Rate": round(nominal_rate, 4),
        "Lexical Density": round(lexical_density, 4)
    }


def main(input_csv: str, output_csv: str):
    """
    Read the input CSV, compute metrics for each abstract, and save to output CSV.
    """
    df = pd.read_csv(input_csv)
    # Ensure 'Abstract' column has string values
    df['Abstract'] = df['Abstract'].fillna("")
    # Apply metrics function across all abstracts
    metrics_df = df["Abstract"].apply(compute_metrics).apply(pd.Series)
    # Merge metrics with original data
    result_df = pd.concat([df, metrics_df], axis=1)
    # Export to CSV
    result_df.to_csv(output_csv, index=False)

if __name__ == "__main__":
    import argparse
    parser = argparse.ArgumentParser(description="Compute readability and linguistic metrics for abstracts.")
    parser.add_argument("input_csv", help="Path to the input CSV file")
    parser.add_argument("output_csv", help="Path where the output CSV with metrics will be saved")
    args = parser.parse_args()
    main(args.input_csv, args.output_csv)
