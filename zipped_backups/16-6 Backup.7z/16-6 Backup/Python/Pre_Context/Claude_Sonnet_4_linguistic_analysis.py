import pandas as pd
import re
import nltk
import textstat
import spacy
from collections import Counter
import numpy as np
import warnings

# Suppress warnings for cleaner output
warnings.filterwarnings('ignore')

# Download required NLTK data (run once)
def setup_nltk():
    """Download required NLTK data packages"""
    try:
        nltk.download('punkt', quiet=True)
        nltk.download('averaged_perceptron_tagger', quiet=True)
        nltk.download('wordnet', quiet=True)
        nltk.download('stopwords', quiet=True)
        print("NLTK packages downloaded successfully!")
    except Exception as e:
        print(f"Error downloading NLTK packages: {e}")

# Load spaCy model (install with: python -m spacy download en_core_web_sm)
def load_spacy_model():
    """Load spaCy English model for advanced NLP tasks"""
    try:
        nlp = spacy.load("en_core_web_sm")
        print("spaCy model loaded successfully!")
        return nlp
    except OSError:
        print("spaCy model not found. Please install with: python -m spacy download en_core_web_sm")
        return None

class LinguisticAnalyzer:
    """
    A comprehensive linguistic analysis tool for academic abstracts
    """
    
    def __init__(self):
        self.nlp = load_spacy_model()
        
        # Hedging words commonly found in academic writing
        self.hedging_words = {
            'may', 'might', 'could', 'would', 'should', 'possibly', 'probably', 
            'perhaps', 'maybe', 'likely', 'unlikely', 'potential', 'potentially',
            'seem', 'seems', 'appear', 'appears', 'suggest', 'suggests',
            'indicate', 'indicates', 'imply', 'implies', 'assume', 'assumes',
            'presumably', 'conceivably', 'arguably', 'relatively', 'somewhat',
            'rather', 'quite', 'fairly', 'mainly', 'largely', 'generally',
            'typically', 'usually', 'often', 'frequently', 'sometimes',
            'occasionally', 'tend', 'tends', 'incline', 'inclines'
        }
        
        # Common nominalization suffixes
        self.nominalization_suffixes = {
            'tion', 'sion', 'ment', 'ness', 'ity', 'ance', 'ence', 
            'ship', 'hood', 'dom', 'ism', 'age', 'ery', 'ary', 'ory'
        }
    
    def clean_text(self, text):
        """Clean and prepare text for analysis"""
        if pd.isna(text) or text == '':
            return ''
        
        # Convert to string and clean
        text = str(text).strip()
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text)
        return text
    
    def count_words(self, text):
        """Count words in text"""
        if not text:
            return 0
        
        # Split by whitespace and filter out empty strings
        words = [word for word in text.split() if word.strip()]
        return len(words)
    
    def count_sentences(self, text):
        """Count sentences using NLTK"""
        if not text:
            return 0
        
        try:
            sentences = nltk.sent_tokenize(text)
            return len(sentences)
        except:
            # Fallback method
            sentences = re.split(r'[.!?]+', text)
            return len([s for s in sentences if s.strip()])
    
    def average_sentence_length(self, text):
        """Calculate average sentence length in words"""
        word_count = self.count_words(text)
        sentence_count = self.count_sentences(text)
        
        if sentence_count == 0:
            return 0
        
        return round(word_count / sentence_count, 2)
    
    def flesch_reading_ease(self, text):
        """Calculate Flesch Reading Ease score"""
        if not text:
            return 0
        
        try:
            return round(textstat.flesch_reading_ease(text), 2)
        except:
            return 0
    
    def flesch_kincaid_grade(self, text):
        """Calculate Flesch-Kincaid Grade Level"""
        if not text:
            return 0
        
        try:
            return round(textstat.flesch_kincaid_grade(text), 2)
        except:
            return 0
    
    def count_syllables(self, text):
        """Count total syllables in text"""
        if not text:
            return 0
        
        try:
            return textstat.syllable_count(text)
        except:
            return 0
    
    def gunning_fog_index(self, text):
        """Calculate Gunning Fog Index"""
        if not text:
            return 0
        
        try:
            return round(textstat.gunning_fog(text), 2)
        except:
            return 0
    
    def count_complex_words(self, text):
        """Count words with 3 or more syllables"""
        if not text:
            return 0
        
        words = re.findall(r'\b\w+\b', text.lower())
        complex_count = 0
        
        for word in words:
            try:
                if textstat.syllable_count(word) >= 3:
                    complex_count += 1
            except:
                continue
        
        return complex_count
    
    def smog_index(self, text):
        """Calculate SMOG Index"""
        if not text:
            return 0
        
        try:
            return round(textstat.smog_index(text), 2)
        except:
            return 0
    
    def count_hedging_words(self, text):
        """Count hedging words in text"""
        if not text:
            return 0
        
        words = re.findall(r'\b\w+\b', text.lower())
        hedging_count = sum(1 for word in words if word in self.hedging_words)
        
        return hedging_count
    
    def hedging_percentage(self, text):
        """Calculate hedging percentage relative to word count"""
        word_count = self.count_words(text)
        hedging_count = self.count_hedging_words(text)
        
        if word_count == 0:
            return 0
        
        return round((hedging_count / word_count) * 100, 2)
    
    def passive_voice_ratio(self, text):
        """Calculate passive voice ratio using spaCy"""
        if not text or not self.nlp:
            return 0
        
        try:
            doc = self.nlp(text)
            total_sentences = len(list(doc.sents))
            passive_count = 0
            
            for sent in doc.sents:
                # Look for passive voice indicators
                for token in sent:
                    # Check for "be" verbs followed by past participles
                    if (token.lemma_ in ['be', 'get'] and 
                        token.head.pos_ == 'VERB' and 
                        token.head.tag_ in ['VBN']):
                        passive_count += 1
                        break
            
            if total_sentences == 0:
                return 0
            
            return round((passive_count / total_sentences) * 100, 2)
        
        except:
            return 0
    
    def nominalization_rate(self, text):
        """Calculate nominalization rate"""
        if not text:
            return 0
        
        words = re.findall(r'\b\w+\b', text.lower())
        total_words = len(words)
        nominalization_count = 0
        
        for word in words:
            if any(word.endswith(suffix) for suffix in self.nominalization_suffixes):
                nominalization_count += 1
        
        if total_words == 0:
            return 0
        
        return round((nominalization_count / total_words) * 100, 2)
    
    def lexical_density(self, text):
        """Calculate lexical density (content words / total words)"""
        if not text or not self.nlp:
            return 0
        
        try:
            doc = self.nlp(text)
            total_words = len([token for token in doc if token.is_alpha])
            
            # Content words: nouns, verbs, adjectives, adverbs
            content_words = len([token for token in doc 
                               if token.pos_ in ['NOUN', 'VERB', 'ADJ', 'ADV'] 
                               and token.is_alpha])
            
            if total_words == 0:
                return 0
            
            return round((content_words / total_words) * 100, 2)
        
        except:
            return 0
    
    def analyze_text(self, text):
        """Perform complete linguistic analysis on text"""
        text = self.clean_text(text)
        
        return {
            'word_count': self.count_words(text),
            'sentence_count': self.count_sentences(text),
            'avg_sentence_length': self.average_sentence_length(text),
            'flesch_ease': self.flesch_reading_ease(text),
            'flesch_kincaid': self.flesch_kincaid_grade(text),
            'syllable_count': self.count_syllables(text),
            'gunning_fog': self.gunning_fog_index(text),
            'complex_words': self.count_complex_words(text),
            'smog_index': self.smog_index(text),
            'hedging_freq': self.count_hedging_words(text),
            'hedging_percent': self.hedging_percentage(text),
            'passive_voice': self.passive_voice_ratio(text),
            'nominalization': self.nominalization_rate(text),
            'lexical_density': self.lexical_density(text)
        }

def process_csv(input_file, output_file):
    """
    Main function to process CSV file and add linguistic metrics
    
    Args:
        input_file (str): Path to input CSV file
        output_file (str): Path to output CSV file
    """
    
    print("Setting up analysis tools...")
    setup_nltk()
    analyzer = LinguisticAnalyzer()
    
    print(f"Loading data from {input_file}...")
    try:
        df = pd.read_csv(input_file)
        print(f"Loaded {len(df)} rows of data")
    except Exception as e:
        print(f"Error loading CSV: {e}")
        return
    
    # Verify the Abstract column exists (Column F)
    if 'Abstract' not in df.columns and len(df.columns) >= 6:
        df.columns = list(df.columns[:6]) + ['Abstract'] + list(df.columns[7:])
    
    # Create new columns for linguistic metrics
    print("Analyzing abstracts and calculating linguistic metrics...")
    
    # Initialize progress tracking
    total_rows = len(df)
    
    # Lists to store results
    results = []
    
    for idx, row in df.iterrows():
        if idx % 100 == 0:  # Progress indicator
            print(f"Processing row {idx + 1}/{total_rows}...")
        
        abstract_text = row.get('Abstract', '') if 'Abstract' in df.columns else row.iloc[5] if len(row) > 5 else ''
        
        # Perform analysis
        analysis = analyzer.analyze_text(abstract_text)
        results.append(analysis)
    
    # Add new columns to dataframe
    df['Word_Count'] = [r['word_count'] for r in results]
    df['Sentence_Count'] = [r['sentence_count'] for r in results]
    df['Avg_Sentence_Length'] = [r['avg_sentence_length'] for r in results]
    df['Flesch_Reading_Ease'] = [r['flesch_ease'] for r in results]
    df['Flesch_Kincaid_Grade'] = [r['flesch_kincaid'] for r in results]
    df['Syllable_Count'] = [r['syllable_count'] for r in results]
    df['Gunning_Fog_Index'] = [r['gunning_fog'] for r in results]
    df['Complex_Word_Count'] = [r['complex_words'] for r in results]
    df['SMOG_Index'] = [r['smog_index'] for r in results]
    df['Hedging_Frequency'] = [r['hedging_freq'] for r in results]
    df['Hedging_Percentage'] = [r['hedging_percent'] for r in results]
    df['Passive_Voice_Ratio'] = [r['passive_voice'] for r in results]
    df['Nominalization_Rate'] = [r['nominalization'] for r in results]
    df['Lexical_Density'] = [r['lexical_density'] for r in results]
    
    # Save results
    print(f"Saving results to {output_file}...")
    try:
        df.to_csv(output_file, index=False)
        print(f"Analysis complete! Results saved to {output_file}")
        print(f"Added {len([r for r in results])} rows with linguistic metrics")
    except Exception as e:
        print(f"Error saving file: {e}")

# Example usage and installation instructions
def main():
    """
    Main function with example usage
    """
    print("=== Linguistic Analysis Tool ===")
    print("This script requires the following packages:")
    print("pip install pandas nltk textstat spacy numpy")
    print("python -m spacy download en_core_web_sm")
    print()
    
    # Example usage
    input_csv = "input_data.csv"  # Replace with your input file path
    output_csv = "output_with_linguistics.csv"  # Replace with desired output path
    
    print("To use this script:")
    print(f"1. Place your CSV file as '{input_csv}'")
    print("2. Run: process_csv('{input_csv}', '{output_csv}')")
    print()
    
    # Uncomment the line below to run the analysis
    # process_csv(input_csv, output_csv)

if __name__ == "__main__":
    main()

# For direct execution, uncomment and modify these lines:
# INPUT_FILE = "your_input_file.csv"
# OUTPUT_FILE = "your_output_file.csv"
# process_csv(INPUT_FILE, OUTPUT_FILE)